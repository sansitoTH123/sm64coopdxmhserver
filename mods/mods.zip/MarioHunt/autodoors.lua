-- name: Automatic Doors
-- description: By Sunk and Blocky. Makes doors open automatically (or get destroyed)

doorsCanClose = false
doorsClosing = false

---@param o Object
function set_new_cost(o)
  if gGlobalSyncTable.gameArea ~= 0 then
    local data = ROMHACK and ROMHACK.gameAreaData and ROMHACK.gameAreaData[gGlobalSyncTable.gameArea + 1]
    if data and data.doorCost then
      local starsNeeded = (o.oBehParams >> 24)
      if data.doorCost[starsNeeded] then
        o.oBehParams = o.oBehParams & 0x00FFFFFF | (data.doorCost[starsNeeded] << 24)
      end
    end
  end
end

---@param o Object
function door_loop(o)
  -- fixes for: replica comet, bbh back entrance, and underworld
  local m = gMarioStates[0]
  if gNetworkPlayers[0].currLevelNum == LEVEL_TTC and gGlobalSyncTable.romhackFile == "coop-romhacks-star-road" then return end
  if gNetworkPlayers[0].currLevelNum == LEVEL_BBH and o.oDoorUnkF8 == 28 then
    if m.usedObj == o and m.action == ACT_PUSHING_DOOR and m.actionTimer == 1 then
      m.area.camera.cutscene = CUTSCENE_DOOR_PUSH
      play_cutscene(m.area.camera)
    end
    return
  end
  if ROMHACK.isUnder then return end

  -- check if the door has enough stars to be opened
  local starsNeeded = (o.oBehParams >> 24) -- this gets the star count
  if gGlobalSyncTable.freeRoam then
    starsNeeded = 0
  elseif gGlobalSyncTable.starRun and gGlobalSyncTable.starRun ~= -1 and gGlobalSyncTable.starRun <= starsNeeded then
    local np = gNetworkPlayers[0]
    starsNeeded = gGlobalSyncTable.starRun
    if (np.currAreaIndex ~= 2) and is_vanilla_like(true) then
      starsNeeded = starsNeeded - 1
    end
  end

  if m.numStars >= starsNeeded then
    -- completely remove collision and hitbox
    o.collisionData = nil
    o.hitboxRadius = 0
    o.hitboxHeight = 0
    if o.oAction == 0 then
      -- if mario is close enough, set action to the custom open door action, 5
      if dist_between_objects(o, gMarioStates[0].marioObj) <= 400 then
        o.oAction = 5
      end
    end
  end

  if o.oAction == 5 then
    if o.oTimer == 0 then
      -- when the object timer is 0 (when we first set the action to 5) play a sound and init the animation
      cur_obj_init_animation_with_sound(2)

      if cur_obj_has_model(0x1F) ~= 0 then -- metal door
        cur_obj_play_sound_2(SOUND_GENERAL_OPEN_IRON_DOOR)
      else
        cur_obj_play_sound_2(SOUND_GENERAL_OPEN_WOOD_DOOR)
      end
    end

    if o.header.gfx.animInfo.animFrame < 10 then
      o.header.gfx.animInfo.animFrame = 10 -- make door opening feel snappier
    end

    -- 40 is the anim frame where the door is fully opened
    if o.header.gfx.animInfo.animFrame >= 40 then
      o.header.gfx.animInfo.animFrame = 40
      o.header.gfx.animInfo.prevAnimFrame = 40
    end

    -- if we are far from the door, go to the custom close door action, 6
    if dist_between_objects(o, gMarioStates[0].marioObj) > 400 then
      o.oAction = 6
    end
  end

  if o.oAction == 6 then
    -- since the action is no longer 5, the animation continues, 78 is the end of the animation (take 2 frames)
    if o.header.gfx.animInfo.animFrame >= 78 then
      -- play object sound, and set action to 0
      if cur_obj_has_model(0x1F) ~= 0 then -- metal door
        cur_obj_play_sound_2(SOUND_GENERAL_CLOSE_IRON_DOOR)
      else
        cur_obj_play_sound_2(SOUND_GENERAL_CLOSE_WOOD_DOOR)
      end
      o.oAction = 0
    end
  end
end

function star_door_loop(o)
  local partner = cur_obj_nearest_object_with_behavior(o.behavior) or o
  local m = gMarioStates[0]
  local starsNeeded = (o.oBehParams >> 24) or 0   -- this gets the star count
  if gGlobalSyncTable.freeRoam then
    starsNeeded = 0
  elseif gGlobalSyncTable.starRun and gGlobalSyncTable.starRun ~= -1 and gGlobalSyncTable.starRun <= starsNeeded then
    local np = gNetworkPlayers[0]
    starsNeeded = gGlobalSyncTable.starRun
    if (np.currAreaIndex ~= 2) and is_vanilla_like(true) then
      starsNeeded = starsNeeded - 1
    end
  end

  if starsNeeded <= m.numStars and (dist_between_objects(m.marioObj, o) <= 800 and dist_between_objects(m.marioObj, partner) <= 800) then
    o.oIntangibleTimer = -1
    if o.oAction == 0 then
      o.oAction = 1
    elseif o.oAction == 2 then
      o.oTimer = 0
    end
  end
end

hook_behavior(id_bhvDoor, OBJ_LIST_SURFACE, false, set_new_cost, door_loop, "bhvMhCustomDoor")
hook_behavior(id_bhvStarDoor, OBJ_LIST_SURFACE, false, set_new_cost, star_door_loop, "bhvMhCustomStarDoor")
